import javax.swing.JOptionPane;
import java.sql.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.JComboBox;
import com.toedter.calendar.JDateChooser;
import javax.swing.DefaultCellEditor;
import javax.swing.table.TableCellEditor;
import java.awt.Component;
import javax.swing.AbstractCellEditor;
import javax.swing.JTable;



/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */


/**
 *
 * @author hezekiahmagalona
 */
public class shipments extends javax.swing.JPanel {
    private Connection conn;
    private String[] originalIds;
    private Object[][] originalData;
    
    /**
     * Creates new form customer
     */
    public shipments() {
    initComponents();

    try {
        conn = getConnection();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this,
                "Database connection failed: " + e.getMessage());
        return;
    }

    loadShipmentTable();
    customizeShipmentTable();
    centerAlignShipmentTable();
}
    
    
    private void centerAlignShipmentTable() {
        javax.swing.table.DefaultTableCellRenderer centerRenderer =
                new javax.swing.table.DefaultTableCellRenderer();

        centerRenderer.setHorizontalAlignment(javax.swing.JLabel.CENTER);

        for (int i = 0; i < shipmenttable.getColumnCount(); i++) {
            shipmenttable.getColumnModel().getColumn(i)
                    .setCellRenderer(centerRenderer);
        }
    }
    
    private Connection getConnection() throws Exception {
        String url = "jdbc:sqlserver://localhost:1433;"
                + "databaseName=ifcdb;"
                + "encrypt=true;"
                + "trustServerCertificate=true";

        String user = "sa";
        String password = "Anolagam28";

        return java.sql.DriverManager.getConnection(url, user, password);
    }
    
    public class DateCellEditor
            extends AbstractCellEditor
            implements TableCellEditor {

        private JDateChooser dateChooser;

        public DateCellEditor() {

            dateChooser = new JDateChooser();

            dateChooser.setDateFormatString(
                    "yyyy-MM-dd");
        }

        @Override
        public Object getCellEditorValue() {

            return dateChooser.getDate();
        }

        @Override
        public Component getTableCellEditorComponent(
                JTable table,
                Object value,
                boolean isSelected,
                int row,
                int column) {

            if (value instanceof java.util.Date) {

                dateChooser.setDate(
                        (java.util.Date) value);

            } else {

                dateChooser.setDate(null);
            }

            return dateChooser;
        }
    }
    
    private void loadShipmentTable() {

        try {

            String sql =
                    "SELECT shipment_id, order_id, "
                    + "shipment_date, delivery_mode, "
                    + "courier, shipment_status "
                    + "FROM dbo.Shipments";

            PreparedStatement pst =
                    conn.prepareStatement(sql);

            ResultSet rs =
                    pst.executeQuery();

            DefaultTableModel model =
                    new DefaultTableModel() {

                @Override
                public boolean isCellEditable(
                        int row,
                        int column) {

                    return column != 0;
                }
            };

            model.setColumnIdentifiers(new String[]{
                "Shipment ID",
                "Order ID",
                "Shipment Date",
                "Delivery Mode",
                "Courier",
                "Status"
            });

            java.util.List<String> idList =
                    new java.util.ArrayList<>();

            java.util.List<Object[]> dataList =
                    new java.util.ArrayList<>();

            while (rs.next()) {

                String shipmentId =
                        rs.getString("shipment_id");

                Object[] row = new Object[]{
                    shipmentId,
                    rs.getInt("order_id"),
                    rs.getDate("shipment_date"),
                    rs.getString("delivery_mode"),
                    rs.getString("courier"),
                    rs.getString("shipment_status")
                };

                model.addRow(row);

                idList.add(shipmentId);
                dataList.add(row);
            }

            originalIds =
                    idList.toArray(new String[0]);

            originalData =
                    dataList.toArray(new Object[0][]);

            shipmenttable.setModel(model);

            customizeShipmentTable();

            shipmenttable.getColumnModel()
                    .getColumn(2)
                    .setCellEditor(
                            new DateCellEditor());

            String[] statuses = {
                "Pending",
                "Shipped",
                "Delivered",
                "Cancelled"
            };

            JComboBox<String> comboBox =
                    new JComboBox<>(statuses);

            shipmenttable.getColumnModel()
                    .getColumn(5)
                    .setCellEditor(
                            new DefaultCellEditor(comboBox));

            rs.close();
            pst.close();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error loading shipments: "
                    + e.getMessage());
        }
    }
        
        private void customizeShipmentTable() {

        shipmenttable.setBackground(java.awt.Color.WHITE);

        shipmenttable.setForeground(
                new java.awt.Color(25, 25, 25));

        shipmenttable.setFont(
                new java.awt.Font(
                        "Baskerville",
                        java.awt.Font.PLAIN,
                        18));

        shipmenttable.setRowHeight(38);

        shipmenttable.setGridColor(
                new java.awt.Color(220, 220, 220));

        shipmenttable.setShowGrid(true);
        shipmenttable.setShowVerticalLines(false);

        shipmenttable.setSelectionBackground(
                new java.awt.Color(35, 35, 35));

        shipmenttable.setSelectionForeground(
                java.awt.Color.WHITE);

        shipmenttable.setAutoResizeMode(
                javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);

        shipmenttable.setFillsViewportHeight(true);

        shipmenttable.getColumnModel()
                .getColumn(0)
                .setMinWidth(100);

        shipmenttable.getColumnModel()
                .getColumn(0)
                .setPreferredWidth(120);

        shipmenttable.getColumnModel()
                .getColumn(0)
                .setMaxWidth(140);

        javax.swing.table.JTableHeader header =
                shipmenttable.getTableHeader();

        header.setPreferredSize(
                new java.awt.Dimension(
                        header.getWidth(),
                        42));

        header.setReorderingAllowed(false);
        header.setResizingAllowed(true);

        javax.swing.table.DefaultTableCellRenderer headerRenderer =
                new javax.swing.table.DefaultTableCellRenderer();

        headerRenderer.setHorizontalAlignment(
                javax.swing.JLabel.CENTER);

        headerRenderer.setBackground(
                new java.awt.Color(28, 28, 28));

        headerRenderer.setForeground(
                java.awt.Color.WHITE);

        headerRenderer.setFont(
                new java.awt.Font(
                        "Big Caslon",
                        java.awt.Font.BOLD,
                        18));

        headerRenderer.setBorder(
                javax.swing.BorderFactory
                        .createMatteBorder(
                                0,
                                0,
                                1,
                                1,
                                new java.awt.Color(65, 65, 65)));

        for (int i = 0;
             i < shipmenttable.getColumnModel().getColumnCount();
             i++) {

            shipmenttable.getColumnModel()
                    .getColumn(i)
                    .setHeaderRenderer(headerRenderer);
        }

        centerAlignShipmentTable();
    }
        
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        back = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        edittable = new javax.swing.JButton();
        searchshipmentID = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        shipmenttable = new javax.swing.JTable();
        refresh = new javax.swing.JButton();
        save = new javax.swing.JButton();
        bg = new javax.swing.JLabel();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ifccrafts/assets/back.png"))); // NOI18N
        back.setBorderPainted(false);
        back.setContentAreaFilled(false);
        back.setFocusPainted(false);
        back.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        back.addActionListener(this::backActionPerformed);
        add(back, new org.netbeans.lib.awtextra.AbsoluteConstraints(98, 75, -1, 77));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 280, -1, 70));

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 380, -1, 70));

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 480, -1, 70));

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 180, -1, 70));

        edittable.setBackground(new java.awt.Color(255, 255, 255));
        edittable.setFont(new java.awt.Font("Kokonor", 0, 18)); // NOI18N
        edittable.setForeground(new java.awt.Color(0, 0, 0));
        edittable.setText("Add/Delete");
        edittable.addActionListener(this::edittableActionPerformed);
        add(edittable, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 100, 120, 40));

        searchshipmentID.setBackground(new java.awt.Color(255, 255, 255));
        searchshipmentID.setFont(new java.awt.Font("Kokonor", 0, 18)); // NOI18N
        searchshipmentID.setForeground(new java.awt.Color(0, 0, 0));
        searchshipmentID.setText("Search Shipment ID");
        searchshipmentID.addActionListener(this::searchshipmentIDActionPerformed);
        add(searchshipmentID, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 100, 570, 40));

        jScrollPane1.setBackground(new java.awt.Color(204, 204, 204));

        shipmenttable.setBackground(new java.awt.Color(255, 255, 255));
        shipmenttable.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        shipmenttable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(shipmenttable);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 170, 1070, 580));

        refresh.setBackground(new java.awt.Color(255, 255, 255));
        refresh.setFont(new java.awt.Font("Kokonor", 0, 18)); // NOI18N
        refresh.setForeground(new java.awt.Color(0, 0, 0));
        refresh.setText("Refresh");
        refresh.addActionListener(this::refreshActionPerformed);
        add(refresh, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 100, 120, 40));

        save.setBackground(new java.awt.Color(255, 255, 255));
        save.setFont(new java.awt.Font("Kokonor", 0, 18)); // NOI18N
        save.setForeground(new java.awt.Color(0, 0, 0));
        save.setText("Save");
        save.addActionListener(this::saveActionPerformed);
        add(save, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 100, 120, 40));

        bg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ifccrafts/assets/mainbg.png"))); // NOI18N
        bg.setText("jLabel5");
        add(bg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1300, 850));
    }// </editor-fold>//GEN-END:initComponents

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        javax.swing.JFrame frame =
        (javax.swing.JFrame) javax.swing.SwingUtilities.getWindowAncestor(this);

        frame.setContentPane(new homepage());
        frame.revalidate();
        frame.repaint();
    }//GEN-LAST:event_backActionPerformed

    private void edittableActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edittableActionPerformed
        javax.swing.JFrame frame =
        (javax.swing.JFrame) javax.swing.SwingUtilities.getWindowAncestor(this);

        frame.setContentPane(new editshipment());
        frame.revalidate();
        frame.repaint(); 
    }//GEN-LAST:event_edittableActionPerformed

    private void searchshipmentIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchshipmentIDActionPerformed
        String inputShipmentID =
                JOptionPane.showInputDialog(
                        this,
                        "Enter Shipment ID:");

        if (inputShipmentID == null
                || inputShipmentID.trim().isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter an ID.");

            return;
        }

        try {

            String sql =
                    "SELECT shipment_id, order_id, "
                    + "shipment_date, delivery_mode, "
                    + "courier, shipment_status "
                    + "FROM dbo.Shipments "
                    + "WHERE CAST(shipment_id AS VARCHAR(30)) LIKE ?";

            PreparedStatement pst =
                    conn.prepareStatement(sql);

            pst.setString(
                    1,
                    "%" + inputShipmentID.trim() + "%");

            ResultSet rs =
                    pst.executeQuery();

            DefaultTableModel model =
                    new DefaultTableModel() {

                @Override
                public boolean isCellEditable(
                        int row,
                        int column) {

                    return column != 0;
                }
            };

            model.setColumnIdentifiers(new String[]{
                "Shipment ID",
                "Order ID",
                "Shipment Date",
                "Delivery Mode",
                "Courier",
                "Status"
            });

            java.util.List<String> idList =
                    new java.util.ArrayList<>();

            java.util.List<Object[]> dataList =
                    new java.util.ArrayList<>();

            boolean found = false;

            while (rs.next()) {

                found = true;

                String shipmentId =
                        rs.getString("shipment_id");

                Object[] row = new Object[]{
                    shipmentId,
                    rs.getInt("order_id"),
                    rs.getDate("shipment_date"),
                    rs.getString("delivery_mode"),
                    rs.getString("courier"),
                    rs.getString("shipment_status")
                };

                model.addRow(row);

                idList.add(shipmentId);
                dataList.add(row);
            }

            if (!found) {

                JOptionPane.showMessageDialog(
                        this,
                        "No matching record found.");

                rs.close();
                pst.close();

                return;
            }

            originalIds =
                    idList.toArray(new String[0]);

            originalData =
                    dataList.toArray(new Object[0][]);

            shipmenttable.setModel(model);

            customizeShipmentTable();

            shipmenttable.getColumnModel()
                    .getColumn(2)
                    .setCellEditor(
                            new DateCellEditor());

            String[] statuses = {
                "Pending",
                "Shipped",
                "Delivered",
                "Cancelled"
            };

            JComboBox<String> comboBox =
                    new JComboBox<>(statuses);

            shipmenttable.getColumnModel()
                    .getColumn(5)
                    .setCellEditor(
                            new DefaultCellEditor(comboBox));

            rs.close();
            pst.close();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Search error: "
                    + e.getMessage());
        }
    }//GEN-LAST:event_searchshipmentIDActionPerformed

    private void refreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshActionPerformed
        loadShipmentTable();
        JOptionPane.showMessageDialog(this, "All records are now displayed.");
    }//GEN-LAST:event_refreshActionPerformed

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
        DefaultTableModel model = (DefaultTableModel) shipmenttable.getModel();

        // Safe Fallback: Verify that original mapping array sizes still align with active visible model rows
        if (originalData == null || originalData.length != model.getRowCount()) {
            JOptionPane.showMessageDialog(this, "Table state is out of sync. Please hit refresh before applying updates.");
            return;
        }

        try (Connection conn = getConnection()) {

            for (int i = 0; i < model.getRowCount(); i++) {
                boolean changed = false;

                for (int j = 0; j < model.getColumnCount(); j++) {
                    Object oldVal = originalData[i][j];
                    Object newVal = model.getValueAt(i, j);

                    if ((oldVal == null && newVal != null) ||
                        (oldVal != null && !oldVal.toString().equals(newVal.toString()))) {
                        changed = true;
                        break;
                    }
                }

                if (!changed) {
                    continue;
                }

                StringBuilder preview = new StringBuilder();
                preview.append("Current Information:\n\n");
                for (int j = 0; j < model.getColumnCount(); j++) {
                    preview.append(model.getColumnName(j)).append(": ").append(originalData[i][j]).append("\n");
                }

                preview.append("\nNew Information:\n\n");
                for (int j = 0; j < model.getColumnCount(); j++) {
                    preview.append(model.getColumnName(j)).append(": ").append(model.getValueAt(i, j)).append("\n");
                }

                int confirm = JOptionPane.showConfirmDialog(this, preview.toString(), "Confirm Save", JOptionPane.YES_NO_OPTION);
                if (confirm != JOptionPane.YES_OPTION) {
                    return;
                }

                int orderId = Integer.parseInt(model.getValueAt(i, 0).toString());
                int productId = Integer.parseInt(model.getValueAt(i, 1).toString());

                String orderCheckSQL = "SELECT order_id FROM Orders WHERE order_id=?";
                try (PreparedStatement orderCheck = conn.prepareStatement(orderCheckSQL)) {
                    orderCheck.setInt(1, orderId);
                    try (ResultSet orderRS = orderCheck.executeQuery()) {
                        if (!orderRS.next()) {
                            JOptionPane.showMessageDialog(this, "Order ID " + orderId + " does not exist.");
                            return;
                        }
                    }
                }

                String productCheckSQL = "SELECT product_id FROM Products WHERE product_id=?";
                try (PreparedStatement productCheck = conn.prepareStatement(productCheckSQL)) {
                    productCheck.setInt(1, productId);
                    try (ResultSet productRS = productCheck.executeQuery()) {
                        if (!productRS.next()) {
                            JOptionPane.showMessageDialog(this, "Product ID " + productId + " does not exist.");
                            return;
                        }
                    }
                }

                String sql = "UPDATE Order_Items SET order_id=?, product_id=?, quantity=? WHERE order_id=? AND product_id=?";
                try (PreparedStatement pst = conn.prepareStatement(sql)) {
                    pst.setInt(1, orderId);
                    pst.setInt(2, productId);
                    pst.setInt(3, Integer.parseInt(model.getValueAt(i, 2).toString()));
                    pst.setInt(4, Integer.parseInt(originalData[i][0].toString()));
                    pst.setInt(5, Integer.parseInt(originalData[i][1].toString()));
                    pst.executeUpdate();
                }
            }

            JOptionPane.showMessageDialog(this, "Changes saved successfully!");
            loadShipmentTable();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Save Processing Aborted: " + e.getMessage());
        }
    }//GEN-LAST:event_saveActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back;
    private javax.swing.JLabel bg;
    private javax.swing.JButton edittable;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton refresh;
    private javax.swing.JButton save;
    private javax.swing.JButton searchshipmentID;
    private javax.swing.JTable shipmenttable;
    // End of variables declaration//GEN-END:variables

}
