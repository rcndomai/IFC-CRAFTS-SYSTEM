
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import com.toedter.calendar.JDateChooser;
import java.awt.Component;



/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */


/**
 *
 * @author hezekiahmagalona
 */
public class order extends javax.swing.JPanel {
    private Connection conn;
    private String[] originalIds;
    private Object[][] originalData;
    private String currentView = "Orders";
   
   
    /**
     * Creates new form customer
     */
    public order() {
        initComponents();
        
        try {
        conn = getConnection();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Database connection failed: " + e.getMessage());
            return;
        }
        
        customizeOrderTable();
        loadOrderTable();
        
        javax.swing.table.DefaultTableCellRenderer centerRenderer = new javax.swing.table.DefaultTableCellRenderer();

        centerRenderer.setHorizontalAlignment(javax.swing.JLabel.CENTER);

        for (int i = 0; i < ordertable.getColumnCount(); i++) {
            ordertable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
    }
    
    private void centerAlignOrderTable() {
        javax.swing.table.DefaultTableCellRenderer centerRenderer =
                new javax.swing.table.DefaultTableCellRenderer();

        centerRenderer.setHorizontalAlignment(javax.swing.JLabel.CENTER);

        for (int i = 0; i < ordertable.getColumnCount(); i++) {
            ordertable.getColumnModel().getColumn(i)
                    .setCellRenderer(centerRenderer);
        }
    }
    
    private Connection getConnection() throws Exception {
        String url = "jdbc:sqlserver://localhost:1433;"
                + "databaseName=ifcdb;"
                + "encrypt=true;"
                + "trustServerCertificate=true";

        String user = "sa";
        String password = "Anolagam28";

        return java.sql.DriverManager.getConnection(url, user, password);
    }
        
      private void loadOrderTable() {
        currentView = "Orders";
        String sql = "SELECT order_id, order_date, due_date, order_status, customer_id, affiliate_id, total_amount FROM dbo.Orders";

        try (PreparedStatement pst = conn.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            DefaultTableModel model = new DefaultTableModel() {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return column != 0 && column != 6;
                }
            };

            model.setColumnIdentifiers(new String[]{
                "Order ID", "Order Date", "Due Date", "Order Status", "Customer ID", "Affiliate ID", "Total Amount"
            });

            java.util.List<String> idList = new java.util.ArrayList<>();
            java.util.List<Object[]> dataList = new java.util.ArrayList<>();

            while (rs.next()) {
                String id = String.valueOf(rs.getInt("order_id"));

                Object[] row = {
                    id,
                    rs.getDate("order_date"),
                    rs.getDate("due_date"),
                    rs.getString("order_status"),
                    rs.getInt("customer_id"),
                    rs.getString("affiliate_id"),
                    rs.getBigDecimal("total_amount")
                };

                model.addRow(row);
                idList.add(id);
                dataList.add(row);
            }

            originalIds = idList.toArray(new String[0]);
            originalData = dataList.toArray(new Object[0][]);

            ordertable.setModel(model);
            customizeOrderTable();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading orders: " + e.getMessage());
        }
    }
      
      private void loadOrderRecord(int orderId) {
        currentView = "Orders";
        String sql = "SELECT order_id, order_date, due_date, order_status, customer_id, affiliate_id, total_amount FROM Orders WHERE order_id = ?";
        
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, orderId);
            try (ResultSet rs = pst.executeQuery()) {
                
                DefaultTableModel model = new DefaultTableModel() {
                    @Override
                    public boolean isCellEditable(int row, int column) {
                        return column != 0 && column != 6;
                    }
                };

                model.setColumnIdentifiers(new String[]{
                    "Order ID", "Order Date", "Due Date", "Order Status", "Customer ID", "Affiliate ID", "Total Amount"
                });

                java.util.List<String> idList = new java.util.ArrayList<>();
                java.util.List<Object[]> dataList = new java.util.ArrayList<>();

                boolean found = false;
                while (rs.next()) {
                    found = true;
                    String id = String.valueOf(rs.getInt("order_id"));

                    Object[] row = {
                        id,
                        rs.getDate("order_date"),
                        rs.getDate("due_date"),
                        rs.getString("order_status"),
                        rs.getInt("customer_id"),
                        rs.getString("affiliate_id"),
                        rs.getBigDecimal("total_amount")
                    };
                    model.addRow(row);
                    idList.add(id);
                    dataList.add(row);
                }

                if (!found) {
                    JOptionPane.showMessageDialog(this, "Order ID not found.");
                    return;
                }

                originalIds = idList.toArray(new String[0]);
                originalData = dataList.toArray(new Object[0][]);
                ordertable.setModel(model);
                customizeOrderTable();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }   
    }
      
     private void loadOrderItemRecord(int orderId) {
       currentView = "Order_Items";
        String sql = "SELECT order_id, product_id, quantity, price_at_order FROM Order_Items WHERE order_id = ?";
        
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, orderId);
            try (ResultSet rs = pst.executeQuery()) {
            
                DefaultTableModel model = new DefaultTableModel() {
                    @Override
                    public boolean isCellEditable(int row, int column) {
                        return column != 0 && column != 1;
                    }
                };

                model.setColumnIdentifiers(new String[]{
                    "Order ID", "Product ID", "Quantity", "Price at Order"
                });

                java.util.List<String> idList = new java.util.ArrayList<>();
                java.util.List<Object[]> dataList = new java.util.ArrayList<>();

                boolean found = false;   
                while (rs.next()) {
                    found = true;
                    String id = String.valueOf(rs.getInt("order_id"));
                    
                    Object[] row = {
                        id,
                        rs.getInt("product_id"),
                        rs.getInt("quantity"),
                        rs.getBigDecimal("price_at_order")
                    };

                    model.addRow(row);
                    idList.add(id);
                    dataList.add(row);
                }

                if (!found) {
                    JOptionPane.showMessageDialog(this, "Order ID not found in items.");
                    return;
                }

                originalIds = idList.toArray(new String[0]);
                originalData = dataList.toArray(new Object[0][]);
                ordertable.setModel(model);
                customizeOrderTable();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    
        public class DateCellEditor extends AbstractCellEditor implements TableCellEditor { 
        private JDateChooser dateChooser;

        public DateCellEditor() {
            dateChooser = new JDateChooser();
        }

        @Override
        public Object getCellEditorValue() {
            return dateChooser.getDate();
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value,
                                                     boolean isSelected, int row, int column) {
            if (value instanceof java.util.Date) {
                dateChooser.setDate((java.util.Date) value);
            }
            return dateChooser;
        }
    }
        
        private void customizeOrderTable() {
        ordertable.setBackground(java.awt.Color.WHITE);
        ordertable.setForeground(new java.awt.Color(25, 25, 25));
        ordertable.setFont(new java.awt.Font("Baskerville", java.awt.Font.PLAIN, 18));
        ordertable.setRowHeight(38);

        ordertable.setGridColor(new java.awt.Color(220, 220, 220));
        ordertable.setShowGrid(true);
        ordertable.setShowVerticalLines(false);

        ordertable.setSelectionBackground(new java.awt.Color(35, 35, 35));
        ordertable.setSelectionForeground(java.awt.Color.WHITE);

        ordertable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        ordertable.setFillsViewportHeight(true);
        
        ordertable.getColumnModel().getColumn(0).setMinWidth(80);
        ordertable.getColumnModel().getColumn(0).setPreferredWidth(100);
        ordertable.getColumnModel().getColumn(0).setMaxWidth(120);

        javax.swing.table.JTableHeader header = ordertable.getTableHeader();
        header.setPreferredSize(new java.awt.Dimension(header.getWidth(), 42));
        header.setReorderingAllowed(false);
        header.setResizingAllowed(true);

        javax.swing.table.DefaultTableCellRenderer headerRenderer = new javax.swing.table.DefaultTableCellRenderer();

        headerRenderer.setHorizontalAlignment(JLabel.CENTER);
        headerRenderer.setBackground(new java.awt.Color(28, 28, 28));
        headerRenderer.setForeground(java.awt.Color.WHITE);
        headerRenderer.setFont(new java.awt.Font("Big Caslon", java.awt.Font.BOLD, 18));
        headerRenderer.setBorder(BorderFactory.createMatteBorder(
                0, 0, 1, 1, new java.awt.Color(65, 65, 65)
        ));

        for (int i = 0; i < ordertable.getColumnModel().getColumnCount(); i++) {
            ordertable.getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
        }
        
        // Dynamic assignment of cell input render items based on lookups
        if (currentView.equals("Orders") && ordertable.getColumnCount() >= 7) {
            ordertable.getColumnModel().getColumn(1).setCellEditor(new DateCellEditor());
            ordertable.getColumnModel().getColumn(2).setCellEditor(new DateCellEditor());

            String[] statuses = {"Not Started", "In Progress", "Done"};
            javax.swing.JComboBox<String> comboBox = new javax.swing.JComboBox<>(statuses);
            ordertable.getColumnModel().getColumn(3).setCellEditor(new javax.swing.DefaultCellEditor(comboBox));
        }
        
        centerAlignOrderTable();
    }
        
     
     
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        back = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        edittable = new javax.swing.JButton();
        searchorderID = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        ordertable = new javax.swing.JTable();
        save = new javax.swing.JButton();
        refresh = new javax.swing.JButton();
        bg = new javax.swing.JLabel();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ifccrafts/assets/back.png"))); // NOI18N
        back.setBorderPainted(false);
        back.setContentAreaFilled(false);
        back.setFocusPainted(false);
        back.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        back.addActionListener(this::backActionPerformed);
        add(back, new org.netbeans.lib.awtextra.AbsoluteConstraints(98, 75, -1, 77));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 280, -1, 70));

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 380, -1, 70));

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 480, -1, 70));

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 180, -1, 70));

        edittable.setBackground(new java.awt.Color(255, 255, 255));
        edittable.setFont(new java.awt.Font("Kokonor", 0, 18)); // NOI18N
        edittable.setForeground(new java.awt.Color(0, 0, 0));
        edittable.setText("Add/Delete");
        edittable.addActionListener(this::edittableActionPerformed);
        add(edittable, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 100, 120, 40));

        searchorderID.setBackground(new java.awt.Color(255, 255, 255));
        searchorderID.setFont(new java.awt.Font("Kokonor", 0, 18)); // NOI18N
        searchorderID.setForeground(new java.awt.Color(0, 0, 0));
        searchorderID.setText("Search Order ID");
        searchorderID.addActionListener(this::searchorderIDActionPerformed);
        add(searchorderID, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 100, 540, 40));

        jScrollPane1.setBackground(new java.awt.Color(204, 204, 204));

        ordertable.setBackground(new java.awt.Color(255, 255, 255));
        ordertable.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        ordertable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(ordertable);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 170, 1070, 580));

        save.setBackground(new java.awt.Color(255, 255, 255));
        save.setFont(new java.awt.Font("Kokonor", 0, 18)); // NOI18N
        save.setForeground(new java.awt.Color(0, 0, 0));
        save.setText("Save");
        save.addActionListener(this::saveActionPerformed);
        add(save, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 100, 120, 40));

        refresh.setBackground(new java.awt.Color(255, 255, 255));
        refresh.setFont(new java.awt.Font("Kokonor", 0, 18)); // NOI18N
        refresh.setForeground(new java.awt.Color(0, 0, 0));
        refresh.setText("Refresh");
        refresh.addActionListener(this::refreshActionPerformed);
        add(refresh, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 100, 120, 40));

        bg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ifccrafts/assets/mainbg.png"))); // NOI18N
        bg.setText("jLabel5");
        add(bg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1300, 850));
    }// </editor-fold>//GEN-END:initComponents

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        javax.swing.JFrame frame =
        (javax.swing.JFrame) javax.swing.SwingUtilities.getWindowAncestor(this);

        frame.setContentPane(new orderpages());
        frame.revalidate();
        frame.repaint();
    }//GEN-LAST:event_backActionPerformed

    private void edittableActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edittableActionPerformed
        JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);

        frame.setContentPane(new editorder());
        frame.revalidate();
        frame.repaint(); 
    }//GEN-LAST:event_edittableActionPerformed

    private void searchorderIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchorderIDActionPerformed
       String input = JOptionPane.showInputDialog(this, "Enter Order ID:");

        if (input == null || input.trim().isEmpty()) {
            return;
        }

        try {
            int orderId = Integer.parseInt(input);

            String[] options = {"Search ID", "View Items"};
            int choice = JOptionPane.showOptionDialog(
                this, "Choose what to view:", "Search",
                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE,
                null, options, options[0]
            );

            if (choice == 0) {
                loadOrderRecord(orderId);
            } else if (choice == 1) {
                loadOrderItemRecord(orderId);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid Order ID.");
        }      
    }//GEN-LAST:event_searchorderIDActionPerformed

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
        DefaultTableModel model = (DefaultTableModel) ordertable.getModel();

        try {
            for (int i = 0; i < model.getRowCount(); i++) {
                boolean changed = false;
                
                for (int j = 0; j < model.getColumnCount(); j++) {
                    Object oldVal = originalData[i][j];
                    Object newVal = model.getValueAt(i, j);

                    if ((oldVal == null && newVal != null) ||
                        (oldVal != null && !oldVal.toString().equals(newVal != null ? newVal.toString() : ""))) {
                        changed = true;
                        break;
                    }
                }

                if (!changed) {
                    JOptionPane.showMessageDialog(this, "No changes detected.");
                    return;
                }

                StringBuilder preview = new StringBuilder();
                preview.append("Current Information:\n\n");
                for (int j = 0; j < model.getColumnCount(); j++) {
                    preview.append(model.getColumnName(j)).append(": ").append(originalData[i][j]).append("\n");
                }

                preview.append("\nNew Information:\n\n");
                for (int j = 0; j < model.getColumnCount(); j++) {
                    preview.append(model.getColumnName(j)).append(": ").append(model.getValueAt(i, j)).append("\n");
                }

                int confirm = JOptionPane.showConfirmDialog(this, preview.toString(), "Confirm Save", JOptionPane.YES_NO_OPTION);
                if (confirm != JOptionPane.YES_OPTION) {
                    return;
                }

                if (currentView.equals("Orders")) {
                    String sql = "UPDATE Orders SET order_date=?, due_date=?, order_status=?, customer_id=?, affiliate_id=?, total_amount=? WHERE order_id=?";
                    try (PreparedStatement pst = conn.prepareStatement(sql)) {
                        
                        // Parse safely handles both java.util.Date and UI casting items
                        Object d1 = model.getValueAt(i, 1);
                        Object d2 = model.getValueAt(i, 2);
                        pst.setDate(1, d1 instanceof java.util.Date ? new java.sql.Date(((java.util.Date)d1).getTime()) : java.sql.Date.valueOf(d1.toString()));
                        pst.setDate(2, d2 instanceof java.util.Date ? new java.sql.Date(((java.util.Date)d2).getTime()) : java.sql.Date.valueOf(d2.toString()));
                        
                        pst.setString(3, model.getValueAt(i, 3).toString());
                        pst.setInt(4, Integer.parseInt(model.getValueAt(i, 4).toString()));
                        pst.setString(5, model.getValueAt(i, 5).toString());
                        pst.setDouble(6, Double.parseDouble(model.getValueAt(i, 6).toString()));
                        pst.setInt(7, Integer.parseInt(model.getValueAt(i, 0).toString()));
                        pst.executeUpdate();
                    }
                } else if (currentView.equals("Order_Items")) {
                    String sql = "UPDATE Order_Items SET quantity=?, price_at_order=? WHERE order_id=? AND product_id=?";
                    try (PreparedStatement pst = conn.prepareStatement(sql)) {
                        pst.setInt(1, Integer.parseInt(model.getValueAt(i, 2).toString()));
                        pst.setDouble(2, Double.parseDouble(model.getValueAt(i, 3).toString()));
                        pst.setInt(3, Integer.parseInt(model.getValueAt(i, 0).toString()));
                        pst.setInt(4, Integer.parseInt(model.getValueAt(i, 1).toString()));
                        pst.executeUpdate();
                    }
                }
            }
            
            JOptionPane.showMessageDialog(this, "Changes saved successfully!");
            loadOrderTable();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error saving: " + e.getMessage());
        }
    }//GEN-LAST:event_saveActionPerformed

    private void refreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshActionPerformed
        loadOrderTable();
        JOptionPane.showMessageDialog(this, "All records are now displayed.");
    }//GEN-LAST:event_refreshActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back;
    private javax.swing.JLabel bg;
    private javax.swing.JButton edittable;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable ordertable;
    private javax.swing.JButton refresh;
    private javax.swing.JButton save;
    private javax.swing.JButton searchorderID;
    // End of variables declaration//GEN-END:variables

}
