import javax.swing.JOptionPane;
import java.awt.BorderLayout;
import java.awt.FontFormatException;
import java.io.IOException;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.layout.VBox;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JLabel;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */


/**
 *
 * @author hezekiahmagalona
 */
public class dashboard extends javax.swing.JPanel {
   
    /**
     * Creates new form customer
     */
    
    private Connection conn;
    private java.awt.Font customFont;
    
    public dashboard() {
        initComponents();
        try {
            conn = getConnection();
            loadFonts();

            best.setFont(customFont.deriveFont(java.awt.Font.BOLD, 28f));
            best1.setFont(customFont.deriveFont(java.awt.Font.BOLD, 28f));
            best2.setFont(customFont.deriveFont(java.awt.Font.BOLD, 28f));

            addPieChart();
            loadSales();
            loadProfit();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Dashboard failed to load: " + e.getMessage());
        }
    }
    
    private void loadFonts() {
        try {
            customFont = java.awt.Font.createFont(
                    java.awt.Font.TRUETYPE_FONT,
                    getClass().getResourceAsStream("/ifccrafts/assets/MyFont.ttf")
            );
        } catch (FontFormatException | IOException e) {
            customFont = new java.awt.Font("Serif", java.awt.Font.PLAIN, 18);
        }
    }
    
    private Connection getConnection() throws Exception {
        String url = "jdbc:sqlserver://localhost:1433;"
                + "databaseName=ifcdb;"
                + "encrypt=true;"
                + "trustServerCertificate=true";

        String user = "sa";
        String password = "Anolagam28";

        return java.sql.DriverManager.getConnection(url, user, password);
    }

    private void addPieChart() {
        // Native JavaFX embedded container
        JFXPanel fxPanel = new JFXPanel();

        bestsellingitems_container.setLayout(new BorderLayout());
        bestsellingitems_container.removeAll();
        bestsellingitems_container.add(fxPanel, BorderLayout.CENTER);
        bestsellingitems_container.revalidate();
        bestsellingitems_container.repaint();

        // Safe async handoff to JavaFX Engine Thread
        Platform.runLater(() -> {
            PieChart pieChart = new PieChart();
            pieChart.setTitle("All-Time Best Sellers");

            try {
                String sql =
                    "SELECT product_id, SUM(quantity) AS total_qty " +
                    "FROM Order_Items " +
                    "GROUP BY product_id " +
                    "ORDER BY total_qty DESC";

                PreparedStatement pst = conn.prepareStatement(sql);
                ResultSet rs = pst.executeQuery();

                while (rs.next()) {
                    int productId = rs.getInt("product_id");
                    int qty = rs.getInt("total_qty");

                    pieChart.getData().add(
                        new PieChart.Data("Product " + productId, qty)
                    );
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            VBox chartCard = new VBox(pieChart);
            chartCard.setStyle(
                "-fx-background-color: white;" +
                "-fx-padding: 20;" +
                "-fx-border-color: #000000;" +
                "-fx-border-width: 3;"
            );

            fxPanel.setScene(new Scene(chartCard));
        });
    }
    
    private void loadSales() {
        try {
            double totalSales = 0;
            double totalExpense = 0;

            // SALES
            String salesSQL = "SELECT SUM(amount) AS totalSales FROM Payments WHERE payment_status='Paid'";
            PreparedStatement pst1 = conn.prepareStatement(salesSQL);
            ResultSet rs1 = pst1.executeQuery();
            if (rs1.next()) {
                totalSales = rs1.getDouble("totalSales");
            }

            // COST
            String expSQL = "SELECT SUM(material_cost) AS totalExpense FROM Inventory";
            PreparedStatement pst2 = conn.prepareStatement(expSQL);
            ResultSet rs2 = pst2.executeQuery();
            if (rs2.next()) {
                totalExpense = rs2.getDouble("totalExpense");
            }

            double profit = totalSales - totalExpense;

            JLabel label = new JLabel("₱ " + profit);
            label.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 30));
            label.setHorizontalAlignment(JLabel.CENTER);

            profit_container.removeAll();
            profit_container.setLayout(new BorderLayout());
            profit_container.add(label, BorderLayout.CENTER);
            profit_container.revalidate();
            profit_container.repaint();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    
    private void besterReload() {
        bestsellingitems_container.removeAll();
        addPieChart();
    }
    
    private void loadProfit() {
        try {

            double totalSales = 0;
            double totalExpense = 0;

            // SALES
            String salesSQL =
                "SELECT SUM(amount) AS totalSales " +
                "FROM Payments WHERE payment_status='Paid'";

            PreparedStatement pst1 = conn.prepareStatement(salesSQL);
            ResultSet rs1 = pst1.executeQuery();

            if (rs1.next()) {
                totalSales = rs1.getDouble("totalSales");
            }

            // COST (Inventory)
            String expSQL =
                "SELECT SUM(material_cost) AS totalExpense FROM Inventory";

            PreparedStatement pst2 = conn.prepareStatement(expSQL);
            ResultSet rs2 = pst2.executeQuery();

            if (rs2.next()) {
                totalExpense = rs2.getDouble("totalExpense");
            }

            double profit = totalSales - totalExpense;

            JLabel label = new JLabel("₱ " + profit);
            label.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 30));
            label.setHorizontalAlignment(JLabel.CENTER);

            profit_container.removeAll();
            profit_container.setLayout(new BorderLayout());
            profit_container.add(label, BorderLayout.CENTER);
            profit_container.revalidate();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    
        private void bestsellerReload() {
            bestsellingitems_container.removeAll();
            addPieChart();
        }
    
    private void loadSalesByDate(int month, int year) {
        try {
            String sql =
                "SELECT SUM(amount) AS totalSales " +
                "FROM Payments " +
                "WHERE payment_status='Paid' " +
                "AND MONTH(date_paid) = ? " +
                "AND YEAR(date_paid) = ?";

            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, month);
            pst.setInt(2, year);

            ResultSet rs = pst.executeQuery();

            double sales = 0;
            if (rs.next()) {
                sales = rs.getDouble("totalSales");
            }

            JLabel label = new JLabel("₱ " + sales);
            label.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 30));
            label.setHorizontalAlignment(JLabel.CENTER);

            sales_container.removeAll();
            sales_container.setLayout(new BorderLayout());
            sales_container.add(label, BorderLayout.CENTER);
            sales_container.revalidate();
            sales_container.repaint();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void loadProfitByDate(int month, int year) {
        try {
            // SALES BY DATE
            String salesSQL =
                "SELECT SUM(amount) AS totalSales " +
                "FROM Payments " +
                "WHERE payment_status='Paid' " +
                "AND MONTH(date_paid)=? " +
                "AND YEAR(date_paid)=?";

            PreparedStatement pst1 = conn.prepareStatement(salesSQL);
            pst1.setInt(1, month);
            pst1.setInt(2, year);
            ResultSet rs1 = pst1.executeQuery();

            double sales = 0;
            if (rs1.next()) {
                sales = rs1.getDouble("totalSales");
            }

            // EXPENSE
            String expSQL = "SELECT SUM(material_cost) AS totalExpense FROM Inventory";
            PreparedStatement pst2 = conn.prepareStatement(expSQL);
            ResultSet rs2 = pst2.executeQuery();

            double expense = 0;
            if (rs2.next()) {
                expense = rs2.getDouble("totalExpense");
            }

            double profit = sales - expense;

            JLabel label = new JLabel("₱ " + profit);
            label.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 30));
            label.setHorizontalAlignment(JLabel.CENTER);

            profit_container.removeAll();
            profit_container.setLayout(new BorderLayout());
            profit_container.add(label, BorderLayout.CENTER);
            profit_container.revalidate();
            profit_container.repaint();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void loadBestSellingByDate(int month, int year) {
        bestsellingitems_container.removeAll();

        JFXPanel fxPanel = new JFXPanel();
        bestsellingitems_container.setLayout(new BorderLayout());
        bestsellingitems_container.add(fxPanel, BorderLayout.CENTER);

        Platform.runLater(() -> {
            PieChart chart = new PieChart();
            chart.setTitle("Best Sellers (" + month + "/" + year + ")");

            try {
                String sql =
                    "SELECT oi.product_id, SUM(oi.quantity) AS total_qty " +
                    "FROM Order_Items oi " +
                    "JOIN Orders o ON oi.order_id = o.order_id " +
                    "WHERE MONTH(o.order_date)=? " +
                    "AND YEAR(o.order_date)=? " +
                    "GROUP BY oi.product_id";

                PreparedStatement pst = conn.prepareStatement(sql);
                pst.setInt(1, month);
                pst.setInt(2, year);

                ResultSet rs = pst.executeQuery();

                while (rs.next()) {
                    chart.getData().add(
                        new PieChart.Data(
                            "Product " + rs.getInt("product_id"),
                            rs.getInt("total_qty")
                        )
                    );
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            // Wrapped inside an explicit container layout card matching standard view
            VBox chartCard = new VBox(chart);
            chartCard.setStyle(
                "-fx-background-color: white;" +
                "-fx-padding: 20;" +
                "-fx-border-color: #000000;" +
                "-fx-border-width: 3;"
            );

            fxPanel.setScene(new Scene(chartCard));
        });

        bestsellingitems_container.revalidate();
        bestsellingitems_container.repaint();
    }
   
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        best2 = new javax.swing.JLabel();
        best1 = new javax.swing.JLabel();
        best = new javax.swing.JLabel();
        back = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        searchdate = new javax.swing.JButton();
        bestsellingitems_container = new javax.swing.JPanel();
        sales_container = new javax.swing.JPanel();
        profit_container = new javax.swing.JPanel();
        refresh = new javax.swing.JButton();
        bg = new javax.swing.JLabel();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        best2.setFont(new java.awt.Font("Big Caslon", 0, 24)); // NOI18N
        best2.setForeground(new java.awt.Color(255, 255, 255));
        best2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        best2.setText("Profit");
        add(best2, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 470, 210, 50));

        best1.setFont(new java.awt.Font("Big Caslon", 0, 24)); // NOI18N
        best1.setForeground(new java.awt.Color(255, 255, 255));
        best1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        best1.setText("Sales");
        add(best1, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 190, 210, 50));

        best.setFont(new java.awt.Font("Big Caslon", 0, 24)); // NOI18N
        best.setForeground(new java.awt.Color(255, 255, 255));
        best.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        best.setText("Best Selling Items");
        add(best, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 190, 390, 50));

        back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ifccrafts/assets/back.png"))); // NOI18N
        back.setBorderPainted(false);
        back.setContentAreaFilled(false);
        back.setFocusPainted(false);
        back.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        back.addActionListener(this::backActionPerformed);
        add(back, new org.netbeans.lib.awtextra.AbsoluteConstraints(98, 75, -1, 77));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 280, -1, 70));

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 380, -1, 70));

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 480, -1, 70));

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 180, -1, 70));

        searchdate.setBackground(new java.awt.Color(255, 255, 255));
        searchdate.setFont(new java.awt.Font("Kokonor", 0, 18)); // NOI18N
        searchdate.setForeground(new java.awt.Color(0, 0, 0));
        searchdate.setText("Search Date");
        searchdate.addActionListener(this::searchdateActionPerformed);
        add(searchdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 90, 150, 40));

        bestsellingitems_container.setLayout(new java.awt.BorderLayout());
        add(bestsellingitems_container, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 250, 490, 460));

        sales_container.setLayout(new java.awt.BorderLayout());
        add(sales_container, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 250, 430, 190));

        profit_container.setLayout(new java.awt.BorderLayout());
        add(profit_container, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 520, 430, 190));

        refresh.setBackground(new java.awt.Color(255, 255, 255));
        refresh.setFont(new java.awt.Font("Kokonor", 0, 18)); // NOI18N
        refresh.setForeground(new java.awt.Color(0, 0, 0));
        refresh.setText("Refresh");
        refresh.addActionListener(this::refreshActionPerformed);
        add(refresh, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 90, 120, 40));

        bg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ifccrafts/assets/mainbg.png"))); // NOI18N
        bg.setText("jLabel5");
        add(bg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1300, 850));
    }// </editor-fold>//GEN-END:initComponents

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        javax.swing.JFrame frame =
        (javax.swing.JFrame) javax.swing.SwingUtilities.getWindowAncestor(this);

        frame.setContentPane(new homepage());
        frame.revalidate();
        frame.repaint();
    }//GEN-LAST:event_backActionPerformed

    private void searchdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchdateActionPerformed
        try {
            String monthInput = JOptionPane.showInputDialog(this, "Enter Month (1-12):");
            String yearInput = JOptionPane.showInputDialog(this, "Enter Year (e.g. 2026):");

            if (monthInput == null || yearInput == null) return;

            int month = Integer.parseInt(monthInput.trim());
            int year = Integer.parseInt(yearInput.trim());

            loadSalesByDate(month, year);
            loadProfitByDate(month, year);
            loadBestSellingByDate(month, year);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid input entry.");
        }
    }//GEN-LAST:event_searchdateActionPerformed

    private void refreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshActionPerformed
        bestsellerReload();
        loadSales();
        loadProfit();

        JOptionPane.showMessageDialog(this, "Dashboard refreshed!");
    }//GEN-LAST:event_refreshActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back;
    private javax.swing.JLabel best;
    private javax.swing.JLabel best1;
    private javax.swing.JLabel best2;
    private javax.swing.JPanel bestsellingitems_container;
    private javax.swing.JLabel bg;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel profit_container;
    private javax.swing.JButton refresh;
    private javax.swing.JPanel sales_container;
    private javax.swing.JButton searchdate;
    // End of variables declaration//GEN-END:variables

 
}
