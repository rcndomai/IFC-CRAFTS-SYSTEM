
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.layout.VBox;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JLabel;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */


/**
 *
 * @author hezekiahmagalona
 */
public class dashboard extends javax.swing.JPanel {
   
    /**
     * Creates new form customer
     */
    private Connection conn;
    public dashboard() {
        initComponents();
        DB_connect();           
        addPieChart();           
        loadSales();             
        loadProfit();            

    }
    private void DB_connect() {
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(
                "jdbc:postgresql://localhost:5432/IFC_Database",
                "postgres",
                "123"
            );
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void addPieChart() {
        JFXPanel fxPanel = new JFXPanel();

        bestsellingitems_container.setLayout(new BorderLayout());
        bestsellingitems_container.add(fxPanel, BorderLayout.CENTER);

        Platform.runLater(() -> {

            PieChart pieChart = new PieChart();

            try {

                String sql =
                    "SELECT product_id, SUM(quantity) AS total_qty " +
                    "FROM Order_Items " +
                    "GROUP BY product_id " +
                    "ORDER BY total_qty DESC";

                PreparedStatement pst = conn.prepareStatement(sql);
                ResultSet rs = pst.executeQuery();

                while (rs.next()) {
                    int productId = rs.getInt("product_id");
                    int qty = rs.getInt("total_qty");

                    pieChart.getData().add(
                        new PieChart.Data("Product " + productId, qty)
                    );
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

            VBox chartCard = new VBox(pieChart);
            chartCard.setStyle(
                "-fx-background-color: white;" +
                "-fx-padding: 20;" +
                "-fx-border-color: black;" +
                "-fx-border-width: 3;"
            );

            fxPanel.setScene(new Scene(chartCard));
        });
    }  
    private void loadSales() {
        try {

            String sql =
                "SELECT SUM(amount) AS totalSales " +
                "FROM Payment " +
                "WHERE payment_status = 'PAID'";

            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                double sales = rs.getDouble("totalSales");

                JLabel label = new JLabel("₱ " + sales);
                label.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 30));
                label.setHorizontalAlignment(JLabel.CENTER);

                sales_container.removeAll();
                sales_container.setLayout(new BorderLayout());
                sales_container.add(label, BorderLayout.CENTER);
                sales_container.revalidate();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    private void loadProfit() {
        try {

            // SALES
            String salesSQL =
                "SELECT SUM(amount) AS totalSales " +
                "FROM Payment WHERE payment_status='PAID'";

            PreparedStatement pst1 = conn.prepareStatement(salesSQL);
            ResultSet rs1 = pst1.executeQuery();

            double totalSales = 0;
            if (rs1.next()) {
                totalSales = rs1.getDouble("totalSales");
            }

            // Inventory expenses
            String expSQL =
                "SELECT SUM(price) AS totalExpense FROM Inventory";

            PreparedStatement pst2 = conn.prepareStatement(expSQL);
            ResultSet rs2 = pst2.executeQuery();

            double totalExpense = 0;
            if (rs2.next()) {
                totalExpense = rs2.getDouble("totalExpense");
            }

            double profit = totalSales - totalExpense;

            JLabel label = new JLabel("₱ " + profit);
            label.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 30));
            label.setHorizontalAlignment(JLabel.CENTER);

            profit_container.removeAll();
            profit_container.setLayout(new BorderLayout());
            profit_container.add(label, BorderLayout.CENTER);
            profit_container.revalidate();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    
    private void bestsellerReload() {
        bestsellingitems_container.removeAll();
        addPieChart();
    }
    private void loadSalesByDate(int month, int year) {
        try {

            String sql =
                "SELECT SUM(amount) AS totalSales " +
                "FROM Payment " +
                "WHERE payment_status='PAID' " +
                "AND EXTRACT(MONTH FROM date_paid) = ? " +
                "AND EXTRACT(YEAR FROM date_paid) = ?";

            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, month);
            pst.setInt(2, year);

            ResultSet rs = pst.executeQuery();

            double sales = 0;
            if (rs.next()) {
                sales = rs.getDouble("totalSales");
            }

            JLabel label = new JLabel("₱ " + sales);
            label.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 30));
            label.setHorizontalAlignment(JLabel.CENTER);

            sales_container.removeAll();
            sales_container.add(label, BorderLayout.CENTER);
            sales_container.revalidate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void loadProfitByDate(int month, int year) {
        try {

            // SALES
            String salesSQL =
                "SELECT SUM(amount) AS totalSales " +
                "FROM Payment " +
                "WHERE payment_status='PAID' " +
                "AND EXTRACT(MONTH FROM date_paid)=? " +
                "AND EXTRACT(YEAR FROM date_paid)=?";

            PreparedStatement pst1 = conn.prepareStatement(salesSQL);
            pst1.setInt(1, month);
            pst1.setInt(2, year);

            ResultSet rs1 = pst1.executeQuery();

            double sales = 0;
            if (rs1.next()) {
                sales = rs1.getDouble("totalSales");
            }

            // EXPENSE
            String expSQL = "SELECT SUM(price) AS totalExpense FROM Inventory";
            PreparedStatement pst2 = conn.prepareStatement(expSQL);
            ResultSet rs2 = pst2.executeQuery();

            double expense = 0;
            if (rs2.next()) {
                expense = rs2.getDouble("totalExpense");
            }

            double profit = sales - expense;

            JLabel label = new JLabel("₱ " + profit);
            label.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 30));
            label.setHorizontalAlignment(JLabel.CENTER);

            profit_container.removeAll();
            profit_container.add(label, BorderLayout.CENTER);
            profit_container.revalidate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void loadBestSellingByDate(int month, int year) {

        bestsellingitems_container.removeAll();

        JFXPanel fxPanel = new JFXPanel();
        bestsellingitems_container.add(fxPanel, BorderLayout.CENTER);

        Platform.runLater(() -> {

            PieChart chart = new PieChart();

            try {

                String sql =
                    "SELECT oi.product_id, SUM(oi.quantity) AS total_qty " +
                    "FROM Order_Items oi " +
                    "JOIN Orders o ON oi.order_id = o.order_id " +
                    "WHERE EXTRACT(MONTH FROM o.order_date)=? " +
                    "AND EXTRACT(YEAR FROM o.order_date)=? " +
                    "GROUP BY oi.product_id";

                PreparedStatement pst = conn.prepareStatement(sql);
                pst.setInt(1, month);
                pst.setInt(2, year);

                ResultSet rs = pst.executeQuery();

                while (rs.next()) {
                    chart.getData().add(
                        new PieChart.Data(
                            "Product " + rs.getInt("product_id"),
                            rs.getInt("total_qty")
                        )
                    );
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

            fxPanel.setScene(new Scene(chart));
        });

        bestsellingitems_container.revalidate();
    }



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        oID2 = new javax.swing.JLabel();
        oID1 = new javax.swing.JLabel();
        oID = new javax.swing.JLabel();
        refresh = new javax.swing.JButton();
        searchdate = new javax.swing.JButton();
        back = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        bestsellingitems_container = new javax.swing.JPanel();
        sales_container = new javax.swing.JPanel();
        profit_container = new javax.swing.JPanel();
        bg = new javax.swing.JLabel();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        oID2.setFont(new java.awt.Font("Big Caslon", 0, 24)); // NOI18N
        oID2.setForeground(new java.awt.Color(255, 255, 255));
        oID2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        oID2.setText("Profit");
        add(oID2, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 450, 60, 50));

        oID1.setFont(new java.awt.Font("Big Caslon", 0, 24)); // NOI18N
        oID1.setForeground(new java.awt.Color(255, 255, 255));
        oID1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        oID1.setText("Best-Selling Items");
        add(oID1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 160, 200, 50));

        oID.setFont(new java.awt.Font("Big Caslon", 0, 24)); // NOI18N
        oID.setForeground(new java.awt.Color(255, 255, 255));
        oID.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        oID.setText("Sales");
        add(oID, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 170, 60, 50));

        refresh.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        refresh.setText("Refresh");
        refresh.addActionListener(this::refreshActionPerformed);
        add(refresh, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 110, 150, 40));

        searchdate.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        searchdate.setText("Search Date");
        searchdate.addActionListener(this::searchdateActionPerformed);
        add(searchdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 110, 150, 40));

        back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ifccrafts/assets/back.png"))); // NOI18N
        back.setBorderPainted(false);
        back.setContentAreaFilled(false);
        back.setFocusPainted(false);
        back.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        back.addActionListener(this::backActionPerformed);
        add(back, new org.netbeans.lib.awtextra.AbsoluteConstraints(98, 75, -1, 77));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 280, -1, 70));

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 380, -1, 70));

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 480, -1, 70));

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 180, -1, 70));

        bestsellingitems_container.setLayout(new java.awt.BorderLayout());
        add(bestsellingitems_container, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 230, 490, 490));

        sales_container.setLayout(new java.awt.BorderLayout());
        add(sales_container, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 230, 430, 210));

        profit_container.setLayout(new java.awt.BorderLayout());
        add(profit_container, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 510, 430, 210));

        bg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ifccrafts/assets/mainbg.png"))); // NOI18N
        bg.setText("jLabel5");
        add(bg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1300, 850));
    }// </editor-fold>//GEN-END:initComponents

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        javax.swing.JFrame frame =
        (javax.swing.JFrame) javax.swing.SwingUtilities.getWindowAncestor(this);

        frame.setContentPane(new homepage());
        frame.revalidate();
        frame.repaint();
    }//GEN-LAST:event_backActionPerformed

    private void refreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshActionPerformed
        bestsellerReload();
        loadSales();
        loadProfit();

        JOptionPane.showMessageDialog(this, "Dashboard refreshed!");

    }//GEN-LAST:event_refreshActionPerformed

    private void searchdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchdateActionPerformed
    try {
        String monthInput = JOptionPane.showInputDialog(this, "Enter Month (1-12):");
        String yearInput = JOptionPane.showInputDialog(this, "Enter Year (e.g. 2026):");

        if (monthInput == null || yearInput == null) return;

        int month = Integer.parseInt(monthInput);
        int year = Integer.parseInt(yearInput);

        loadSalesByDate(month, year);
        loadProfitByDate(month, year);
        loadBestSellingByDate(month, year);

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Invalid input.");
    }


    }//GEN-LAST:event_searchdateActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back;
    private javax.swing.JPanel bestsellingitems_container;
    private javax.swing.JLabel bg;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel oID;
    private javax.swing.JLabel oID1;
    private javax.swing.JLabel oID2;
    private javax.swing.JPanel profit_container;
    private javax.swing.JButton refresh;
    private javax.swing.JPanel sales_container;
    private javax.swing.JButton searchdate;
    // End of variables declaration//GEN-END:variables

}
