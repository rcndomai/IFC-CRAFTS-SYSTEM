const surveyChart =
document.getElementById('surveyChart');

if(surveyChart){

new Chart(surveyChart,{
type:'bar',

data:{
labels:[
'Room Delays',
'Faculty Assignments',
'Professor Reassignments',
'Modality Switches'
],

datasets:[{
label:'Frequency',
data:[65,42,35,28]
}]
}
});

}

// Attendance

const attendanceChart =
document.getElementById('attendanceChart');

if(attendanceChart){

new Chart(attendanceChart,{
type:'line',

data:{
labels:[
'Week 1',
'Week 2',
'Week 3',
'Week 4',
'Week 5'
],

datasets:[
{
label:'Stable',
data:[91,92,93,92,94]
},
{
label:'Unstable',
data:[82,81,83,84,85]
}
]
}
});

}

// Performance

const performanceChart =
document.getElementById('performanceChart');

if(performanceChart){

new Chart(performanceChart,{
type:'bar',

data:{
labels:[
'Block A',
'Block B',
'Block C',
'Block D'
],

datasets:[
{
label:'Stable',
data:[92,91,93,94]
},
{
label:'Unstable',
data:[84,82,81,85]
}
]
}
});

}